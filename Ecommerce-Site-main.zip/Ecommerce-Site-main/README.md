# Ecommerce-Site
Created a website with HTML and tailwind for the sake of Internship
