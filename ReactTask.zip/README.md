# Color-Picker
Color Picker Project Done as an Internship task at TIERS
![Alt text](./img/homePage.PNG)

## Tools and Languages

- React
- Tailwind